export { TheGeneratorPage } from './TheRedTest'
